<?php
require_once "autoloader.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
			$dbMySQL=new MySQLiService();
			/*
			$dbPDO=new PDOService();
			foreach ($dbPDO->getAllFilms() as $film) {
				echo $film->id." ".$film->title."<br />";
			}
			$film=$dbPDO->getFilmByID(3);
			if (!is_null($film)) {
				echo "Film found: ".$film->title."<br />";
			}
			else {
				echo "Not found"."<br />";
			}
			echo "<pre>";
			$films=$dbPDO->getAllFilmsInfo();
			foreach ($films as $film) {
				var_dump($film);
			}
			echo "</pre>";
			*/
			foreach($dbMySQL->getAllCategories() as $category){
				echo  $category->id." ".$category->name."<br />";
			}

        ?>
    </body>
</html>
