<?php

class Film
{
    public $id;
    public $title;
    public $description;// declaration of variables
    public $releaseYear;
    public $length;

    public function __construct($id, $title, $description, $releaseYear, $length)// Film constructor
    {
        $this->id=$id;
        $this->title=$title;
        $this->description=$description;
        $this->releaseYear=$releaseYear;
        $this->length=$length;
    }

}


