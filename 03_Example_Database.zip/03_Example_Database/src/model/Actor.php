<?php

class Actor
{
    public $id;
    public $lastname;// declaration of variables
    public $firstname;

     public function __construct($id, $firstname, $lastname) // Actor constructor
     {
         $this->id=$id;
         $this->firstname=$firstname;
         $this->lastname=$lastname;
     }
}