<?php

class Language
{
    public $id;
    public $name;// declaration of vriables

     public function __construct($id, $name)//  Language constructor
     {
         $this->id=$id;
         $this->name=$name;
     }
}