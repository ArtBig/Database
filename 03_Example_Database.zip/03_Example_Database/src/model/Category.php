<?php

class Category
{
    public $id; //  declaration of variables
    public $name;

     public function __construct($id, $name)// Category constructor
     {
         $this->id=$id;
         $this->name=$name;
     }
}