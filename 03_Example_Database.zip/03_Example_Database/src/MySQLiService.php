<?php

class MySQLiService implements IServiceDB
{	
	private $connectDB;
	
	public function connect() {	// see funktsioon uhendab programm andmebaasiga
		$this->connectDB = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);//here we use mysqli  class and we use a
		// the name of host, userame of database, password, database name from settings.php file.
		$this->connectDB->set_charset(DB_CHARSET);//here we set a charset for database
		if (mysqli_connect_errno()) {// checking if thre are no errors in database connection.
			printf("Connection failed: %s", mysqli_connect_error());// printing the description  of error
			exit();//
		}
		return true;// if ther are no errors in connection returns true
	}
	
	public function getAllFilms()// this function returns the array of films
	{	
		$films=array(); // declaration of veriable films which equals array()
	if ($this->connect()) {// here we call the function connect(), which controlls the connection with database
			if ($result = mysqli_query($this->connectDB, 'SELECT * FROM film')) {// vriable result keeps the result of query from table film
				while ($row = mysqli_fetch_assoc($result)) {//function mysqli_fetch_assoc($result) fetches the query from veriable result as an associative array
					$films[]=new Film($row['film_id'], $row['title'], $row['description'], // here we create a new object of Film class. Give him id , title, description,release year,length and put it into films array.
										$row['release_year'],  $row=['length']);
                 } 
				 mysqli_free_result($result);// releases the memory occupied with results of inquiry.
			}
		    mysqli_close($this->connectDB);	//close the database connection
		}
		return $films;
	}
	
	public function getFilmByID($id)
	{	
		$film=null;
		if ($this->connect()) {
			if ($query = mysqli_prepare($this->connectDB, 'SELECT * FROM film WHERE film_id=?')) {
				/** function mysqli_prepare ( mysqli $link , string $query ) prepare an SQL statement for execution
				 * link parameter is a link identifier returned by mysqli_connect() function 
				 * query parameter is the query as a string
				*/
				$query->bind_param("i", $id); //"i" - $id is integer
				$query->execute();// query execution
				$result = $query->get_result();// veriable result keeps result of query. Function get_result() returns result of veriable query.
				$numRows = $result->num_rows;// declaration numRows veriable , which equals number of rows.Function num_rows gets the number of rows in a result.
				if ($numRows==1) {
					$row=$result->fetch_array(MYSQLI_NUM);// function fetch_array(MYSQLI_NUM) specifies that return array should use numeric keys for the array , instead of creating an associative array.
					$film=new Film($row[0], $row[1], $row[2], $row[3], $row[5]); // creation of Film class with it's parameters
				}
				$query->close();// close database query
			}
		    mysqli_close($this->connectDB);	// close database connection
		}
	    return $film;	
	}

	public function getAllFilmsInfo()
	{
		$films=array();
		if ($this->connect()) {
			if ($result = mysqli_query($this->connectDB, 'SELECT * FROM film_info')) {
				while ($row = mysqli_fetch_assoc($result)) {
					$actors=array();
					foreach (explode(";",$row['actors']) as $item) {
					   $actor=explode(",",$item);
					   $actors[]=new Actor($actor[0], $actor[1],$actor[2]);
					}
					$categories=array();
					foreach (explode(";",$row['categories']) as $item) {
					   $category=explode(",",$item);
					   $categories[]=new Category($category[0], $category[1]);
					}
					$item=explode(',',$row['language']);
					$language=new Language($item[0], $item[1]);
					$films[]=new FilmInfo($row['id'], $row['title'], $row['description'], 
										$row['year'],  $row=['length'], $actors, $categories, $language);
					
                 } 
				 mysqli_free_result($result);
			}
		    mysqli_close($this->connectDB);	
		}
		return $films;
	}
	public function getAllCategories()
	{
		$categories=array();
			if($this->connect()){
				if($result = mysqli_query($this->connectDB,'SELECT * FROM film_info')){
					while($row = mysqli_fetch_assoc($result)){
						foreach(explode(";",$row['categories']) as $item){
							$category=explode(",",$item);
							$categories[]=new Category($category[0], $category[1]);
						}
					}
					

				}
			}
	}

}

